﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaffleManager : Scene
{
    //empty script but exists because otherwise Manager will have nothing to call
    //all needed scripts are functioning on other objects
}
